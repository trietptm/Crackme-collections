(First of all read the text from About/CON fuzed in the menu of the proggie)

Okie, here's what you have to do if you want to help me in my task:
1. make the 3 buttons do what they're supposed to, the first two to show the
first two messages, and the third to exit the app.
2. make the three menu items from 'Menu', do the same things as the three
buttons (using the same order, that is: first-show first message... exit-exit app).
3.change the first item of the 'About' menu, so that it shows a text that
explains what my program attempts to do (the reversed version) in stead of the 
explanations (and get rid of the second messagebox that is shown).


Explanation:
The reverseme was build in Delphi 5 due to the lack of time to do it the 'less
than 10K exes' way. I agree it's less 'artistic', but it's more practical. :P
I think a win32asm ver will be coming out for those of you who don't have enough
patience to do it the 'usual' way, but it's gonna take a while though. And, anyway,
how many 'real-life' programs have you reversed recently that were written in asm or 
win32 c++ ??

that's about it
tank out

MAIL ME: tank__@hotmail.com