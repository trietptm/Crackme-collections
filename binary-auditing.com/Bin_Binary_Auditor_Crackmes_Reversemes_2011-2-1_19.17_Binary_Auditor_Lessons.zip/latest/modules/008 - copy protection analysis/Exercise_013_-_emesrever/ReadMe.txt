Crudd's eMesreveR
This is a crackme without the edit boxes, labels or "check it" button added.  It's a harddrive protection in which a serial is created from your harddrive.
So your goals are:
	Add 3 labels: "Name", "Serial", and "HD Serial" or something to that effect.
	Add 3 edit boxes.  The one for the HD serial should not accept user input and should contain the HD serial when the program starts.  
	Add a button or some way of having the program check the serial. 
	And i think thats it.
Crudd

email me at Crudd2k@netzero.net with questions, solutions, or threats.
Thanks to: C_DKIGHT, TURiS, Muad Dib, WhizKid, Falcon & the GC, everyone in #c4n, L!m!t, Rebelious and all of [TeX], Sheep140 and all of [CrEaM], r!sc, nchanta, Thesmurf, Nitrus, anyone who tries this reverse me,  everyone i forgot, sorry.
