tasks :
~~~~~~~
1) Make the serial "ParaB0y"
2) remove the "mission failed"
3) regain access to the messgaebox that shows what you eneterd
4) regain access to the Good/Bad serial message
5) make the button caption "- Reversed -"
6) make the good serial/bad serial messages as "Good/Bad Serial" (no case senstive)
7) tut the solution...

Protections :
~~~~~~~~~~~~~
1) Immune from W32dasm
2) that all for now =]


rulez :
~~~~~~~
1) patch only =]
2) the patch must keep the sections as they are!
3) no external files usage, that mean, dont make the functions on a .dll and call it...