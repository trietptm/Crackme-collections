Your objective is to make the file run, it doesn't matter much what
kind of tools your going to use, so use whatever you want ;)

Now how do i know that i solved it?
If it runs you should get a MessageBox saying:

Hello there!
Ok I think you solved it, great!

:)

I hope it's not too tough ;)

"TIEP" strange name?
You figure it out ;)


P.S. Don't run the file directly, first examine it ;)