This one isnt Hard...
you need to add a button,
make it with the same font,
Caption : Random
job, show random number on a messagebox
you must not add imports
(especially no wsprintf and such)
but, u can change imports :)))

i've included a function to make hex to decimal string
BUT
you need to find where is it, what param's its using
and that stuff
(the algo is by me!)

ahh,
i think that it :)

and no dll adding stuff...
use what u have !

i managed to finish that reverseme in hour (without adding a single byte to the file!)

i dont think that should take u much :)))
(unless u're really newbies, and u still donno what to do)
i coded that one
cos no good reverseme for advanced newbies is avilable...

so, enjoy it...