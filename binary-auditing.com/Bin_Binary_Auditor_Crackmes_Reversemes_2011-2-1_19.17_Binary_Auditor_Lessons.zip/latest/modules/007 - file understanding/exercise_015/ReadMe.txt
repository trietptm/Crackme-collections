This is a crackme without the edit boxes, labels or "check it" button added.  It's a harddrive protection in which a serial is created from your harddrive.
So your goals are:
	Add 3 labels: "Name", "Serial", and "HD Serial" or something to that effect.
	Add 3 edit boxes.  The one for the HD serial should not accept user input and should contain the HD serial when the program starts.  
	Add a button or some way of having the program check the serial. 
	And i think thats it.
