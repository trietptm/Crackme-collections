Tasks :
~~~~~~~

Crackme :
---------

Good Crackers :
~~~~~~~~~~~~~~~
1) Get a Valid Serial
2) NO PATCHING

NEWBIES :
~~~~~~~~~
1) Patch so the Serial Will be ALWAYS good
2) Make the CRC routine working, on the patched file

Rules :
~~~~~~~

KEEP THE ANTI W32DASM ON !!!

ReverseMe :
-----------

1) Patch it so the serial will be always good.
2) KEEP ON THE CRC VALUE ! Reverse the checking routine ;)
   I'LL Check on you !

3) Add yourself to greetings ;)