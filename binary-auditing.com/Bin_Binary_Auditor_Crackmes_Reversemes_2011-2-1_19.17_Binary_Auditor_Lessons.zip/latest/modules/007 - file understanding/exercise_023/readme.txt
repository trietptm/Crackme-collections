Now, what is it all about: run the program - nothing important happens. That's the idea.

What are you supposed to do:
1.When the user presses the CTRL-ALT-DEL combination, the "Close Program" window appears.
  Suppose we do not like that :P Your first task is thus to change this behaviour: so, 
  when the user presses the CTRL-ALT-DEL combination, instead of the usual system window,
  he will receive a messagebox telling him:"You have pressed CTRL-ALT-DEL!"
2.When the user presses the F1 key on the keyboard, a window will pop up, displaying the
  content of this readme.txt file.
3.Watch out, the exe is packed, I need you to unpack it manually, then operate the changes.
  (That's right, no unpackers.)

Finally, a short explanation on the term CRevMe: it's both a CR[ack] and a Rev[erse] Me, 
better yet, you have to use both cracking and reversing skills, although the first may be
considered as part of the second.