tasks:
~~~~~~

create 2 edit boxes, one for a name, the other for serial
and a button that will check the name/serial, when the check will do,
if its the name u like (ParaBytes,ur nick/some1 u know's real name)
and the code is 31337, the suser will get a good serial msg,
else (wrong name/serial) it will be a bad msg,
remove the static text, and keep on the pe header, as it is.


protections :
~~~~~~~~~~~~~
no anti-sice tricks,
w32dasm ammune, and u have a 'lil surprise... *evil grin*
well, that all...

rules:
~~~~~~
patch, keep on the pe checking routine, change the code to fit in if u add size
to the header, but keep it there, i'l check it for ya...
