//
// bulkbpt.cpp
//

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <diskio.hpp>
#include <dbg.hpp>

// Maximum number of breakpoints that can be set
#define  MAX_BPT     100

// Insert the following two lines into your plugins.cfg file
// Replace pluginname with the filename of your plugin minus
// the extension
//
//	Write_Breakpoints    pluginname     Alt-D   0
//	Read_Breakpoints     pluginname     Alt-E   1
//

void read_breakpoints() {
  char c, ea[9];
  int x = 0, b = 0;
  ea_t ea_list[MAX_BPT];
  
  // Ask the user for the file containing the breakpoints   
  char *file = askfile_cv(0, "", "Breakpoint list file...", NULL);
  
  // Open the file in read-only mode
  FILE *fp = fopenRT(file);
  if (fp == NULL) {
    warning("Unable to open breakpoint list file, %s\n", file);
    return;
  }
  
  // Grab 8-byte chunks from the file   
  while ((c = qfgetc(fp)) != EOF && b < MAX_BPT) {
    if (isalnum(c)) {
      ea[x++] = c;
      if (x == 8) {
        // NULL terminate the string
        ea[x] = 0;
        x = 0;
        
        // Convert the 8 character string to an address
        str2ea(ea, &ea_list[b], 0);
        msg("Adding breakpoint at %a\n", ea_list[b]);
        // Add the breakpoint as a software breakpoint
        add_bpt(ea_list[b], 0, BPT_SOFT);
        b++;
      }
    }
  }
  
  // Close the file handle
  qfclose(fp);    
}

void write_breakpoints() {
  char c, ea[9];
  int x = 0, b = 0;
  ea_t ea_list[MAX_BPT];
  
  // Ask the user for the file to save the breakpoints to
  char *file = askstr(0, "", "Breakpoint list file...", NULL);
  
  // Open the file in write-only mode
  FILE *fp = ecreateT(file);
  
  for (int i = 0; i < get_bpt_qty(); i++) {
    bpt_t bpt;
    char buf[MAXSTR];

    getn_bpt(i, &bpt);
    
    qsnprintf(buf, sizeof(buf)-1, "%08a\n", bpt.ea);
    ewrite(fp, buf, strlen(buf));
  }
  
  // Close the file handle 
  eclose(fp);
}

void IDAP_run(int arg) 
{
  // Depending on the argument supplied,
  // read the breakpoint list from a file and
  // apply it, or write the current breakpoints
  // to a file.
  switch (arg) {
    case 0:
      write_breakpoints();
      break;
    case 1:
    default:
      read_breakpoints();
      break;
  }
}

int IDAP_init(void)
{
  return PLUGIN_KEEP;
}

void IDAP_term(void)
{
  return;
}

// These are irrelevant because they will be overridden by
// plugins.cfg.
char IDAP_comment[] = "Bulk Breakpoint Setter and Recorder";
char IDAP_help[] =
        "Sets breakpoints at a list of addresses in a text file"
        " or saves the current breakpoints to file.\n"
        "The read list must have one address per line.\n";


char IDAP_name[] = "Bulk Breakpoint Setter and Recorder";
char IDAP_hotkey[] = "Alt-B";

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  IDAP_init,
  IDAP_term,
  IDAP_run,
  IDAP_comment,
  IDAP_help,
  IDAP_name,
  IDAP_hotkey
};
