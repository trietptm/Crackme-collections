//
// snaptrace.cpp
//

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <dbg.hpp>

int IDAP_init(void)
{
  return PLUGIN_KEEP;
}

void IDAP_term(void)
{
  return;
}

void IDAP_run(int arg) 
{
  // Set the default start address to the user cursur position
  ea_t eaddr, saddr = get_screen_ea();

  // Allow the user to specify a start address
  askaddr(&saddr, "Address to start tracing at");

  // Set the end address to the end of the current function
  func_t *func = get_func(saddr);
  eaddr = func->endEA;

  // Allow the user to specify an end address
  askaddr(&eaddr, "Address to end tracing at");
	
  // Queue the following

  // Run to the start address
  request_run_to(saddr);
  // Then enable tracing
  request_enable_insn_trace();
  // Run to the end address, tracing all stops in between
  request_run_to(eaddr);
  // Turn off tracing once we've hit the end address
  request_disable_insn_trace();
  // Stop the process once we have what we want
  request_exit_process();

  // Run the above queued requests
  run_requests();

}

char IDAP_comment[] = "Snap Tracer";
char IDAP_help[] = "Allow tracing only between user "
                   "specified addresses\n";


char IDAP_name[] = "Snap Tracer";
char IDAP_hotkey[] = "Alt-T";

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  IDAP_init,
  IDAP_term,
  IDAP_run,
  IDAP_comment,
  IDAP_help,
  IDAP_name,
  IDAP_hotkey
};
