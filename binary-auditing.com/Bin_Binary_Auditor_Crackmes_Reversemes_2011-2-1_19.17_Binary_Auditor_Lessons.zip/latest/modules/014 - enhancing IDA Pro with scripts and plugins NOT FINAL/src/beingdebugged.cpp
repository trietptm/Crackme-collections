//
// beingdebugged.cpp
//

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <kernwin.hpp>
#include <idd.hpp>
#include <dbg.hpp>

int IDAP_init(void) {
  // Only support x86 architecture
  if(strncmp(inf.procName, "metapc", 8) != 0 && inf.filetype != f_PE) {
    warning("Only x86 PE binary type supported, sorry.");
    return PLUGIN_SKIP;
  }

  return PLUGIN_KEEP;
}

void IDAP_term(void) {
	return;
}

void IDAP_run(int arg) {

  // PEB structure, built from NT Internals:
  // http://undocumented.ntinternals.net
  struct _PEB {
    bool InheritedAddressSpace;
    bool ReadImageFileExecOptions;
    bool BeingDebugged;
    unsigned char Junk;
    long MoreJunk;
    void *ImageBaseAddress;
    // The rest has been left out seeing as we don't
    // need it for this example.
  } peb;

  // Get the current thread ID
  thid_t thread_id = get_current_thread();

  // FS:[0] points to the Thread Information Block
  ea_t seg;
  regval_t fs;
  get_reg_val("FS", &fs);
  dbg->thread_get_sreg_base(thread_id, fs.ival, &seg);

  // Load the PEB, the address of which is 0x30 bytes into the TIB
  ea_t peb_addr;
  msg("Reading TIB at %a\n", seg);

  // PEB address lives at 0x30 bytes into the TIB
  dbg->read_memory((ea_t)seg+0x30, (void *)&peb_addr, sizeof(void *));

  // Read the contents of the PEB into buffer
  dbg->read_memory(peb_addr, (void *)&peb, sizeof(_PEB));

  msg("PEB Address: %a, Being debugged (before change): %d, "
    "Image base address: %a\n", 
    peb_addr, 
    peb.BeingDebugged, 
    peb.ImageBaseAddress);

  // Change the flag in the structure and write it to memory
  peb.BeingDebugged ? 
    peb.BeingDebugged = false : peb.BeingDebugged = true;
  dbg->write_memory(peb_addr, (void *)&peb, sizeof(_PEB));

  // Re-read the contents of the PEB into buffer
  dbg->read_memory(peb_addr, (void *)&peb, sizeof(_PEB));
  msg("Being debugged (after change): %d\n", peb.BeingDebugged);
}

char IDAP_comment[] = "PEB BeingDebugged flipper";
char IDAP_help[] = "Switches the BeingDebugged flag in the PEB\n";
char IDAP_name[] = "BeingDebugged flipper";
char IDAP_hotkey[] = "Alt-I";

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  IDAP_init,
  IDAP_term,
  IDAP_run,
  IDAP_comment,
  IDAP_help,
  IDAP_name,
  IDAP_hotkey
};
