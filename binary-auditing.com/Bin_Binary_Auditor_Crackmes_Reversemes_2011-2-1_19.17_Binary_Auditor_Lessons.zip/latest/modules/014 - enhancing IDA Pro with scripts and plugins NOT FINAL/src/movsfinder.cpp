//
// movsfinder.cpp
//

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <allins.hpp>

int IDAP_init(void)
{
  // Only support x86 architecture
  if(strncmp(inf.procName, "metapc", 8) != 0)    {
    warning("Only x86 binary type supported, sorry.");
    return PLUGIN_SKIP;
  }

  return PLUGIN_KEEP;
}

void IDAP_term(void)
{
  return;
}

void IDAP_run(int arg)
{
  // Instructions we're interested in. NN_movs covers movsd, 
  // movsw, etc.
  int movinstrs[] = { NN_movsx, NN_movsd, NN_movs, 0 };

  // Loop through all segments
  for (int s = 0; s < get_segm_qty(); s++) {
    segment_t *seg = getnseg(s);

    // We are only interested in segments containing code.
    if (seg->type == SEG_CODE) {
 
      // Loop through each function
      for (int x = 0; x < get_func_qty(); x++) {
        func_t *f = getn_func(x);
        char funcName[MAXSTR];

        // Get the function name
        get_func_name(f->startEA, funcName, sizeof(funcName)-1);
 
        // Loop through the instructions in each function
        for (ea_t addr = f->startEA; addr < f->endEA; addr++) {

          // Get the flags for this address
          flags_t flags = get_flags_novalue(addr);
 
          // Only look at the address if it's a head byte, i.e.
          // the start of an instruction and is code.
          if (isHead(flags) && isCode(flags)) {
            char mnem[MAXSTR];
 
            // Fill the cmd structure with the disassembly of
            // the current address and get the mnemonic text.
            ua_mnem(addr, mnem, sizeof(mnem)-1);
 
            // Check the mnemonic of the address against all
            // mnemonics we're interested in.
            for (int i = 0; movinstrs[i] != 0; i++) {
              if (cmd.itype == movinstrs[i])
                msg("%s: found %s at %a!\n", funcName, mnem, addr);
            }
          }
        }
      } 
    }
  }

  return;
}

char IDAP_comment[] = "MOVSx Instruction Finder";
char IDAP_help[] =
        "Searches for all MOVS-like instructions.\n"
        "\n"
        "This will display a list of all functions along with\n"
        "the movs instruction used within.";


char IDAP_name[] = "MOVSx Instruction Finder";
char IDAP_hotkey[] = "Alt-M";

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  IDAP_init,
  IDAP_term,
  IDAP_run,
  IDAP_comment,
  IDAP_help,
  IDAP_name,
  IDAP_hotkey
};
