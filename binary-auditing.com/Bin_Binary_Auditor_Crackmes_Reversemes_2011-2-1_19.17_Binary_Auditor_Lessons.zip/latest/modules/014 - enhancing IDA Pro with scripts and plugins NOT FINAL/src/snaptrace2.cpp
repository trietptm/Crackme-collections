//
// snaptrace2.cpp
//

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <dbg.hpp>

ea_t start_ea = 0;
ea_t end_ea = 0;

// Handler for HT_DBG events
int idaapi trace_handler(void *udata, int dbg_event_id, va_list va) 
{
  regval_t esp, eip;

  // Get ESP register value
  get_reg_val("esp", &esp);
  // Get EIP register value
  get_reg_val("eip", &eip);

  // We'll also receive debug events unrelated to tracing,
  // make sure those are filtered out
  if (dbg_event_id == dbg_trace) {
    // Make sure EIP is between the user-specified range
    if (eip.ival > start_ea && eip.ival < end_ea)
	msg("ESP = %a\n", esp.ival);
  }

  return 0;
}

int IDAP_init(void)
{
  // Receive debug event notifications
  hook_to_notification_point(HT_DBG, trace_handler, NULL);
  return PLUGIN_KEEP;
}

void IDAP_term(void)
{
  // Unhook from the notification point on exit
  unhook_from_notification_point(HT_DBG, trace_handler, NULL);
  return;
}

void IDAP_run(int arg) 
{
  // Ask the user for a start and end address
  askaddr(&start_ea, "Start Address:");
  askaddr(&end_ea, "End Address:");
  
  // Queue the following
  
  // Run to the binary entry point
  request_run_to(inf.startIP);
  // Enable step tracing
  request_enable_step_trace();
	
  // Run queued requests
  run_requests();
	
}

char IDAP_comment[] = "Snap Tracer 2";
char IDAP_help[] = "Allow tracing only between user "
                   "specified addresses\n";


char IDAP_name[] = "Snap Tracer 2";
char IDAP_hotkey[] = "Alt-I";

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  IDAP_init,
  IDAP_term,
  IDAP_run,
  IDAP_comment,
  IDAP_help,
  IDAP_name,
  IDAP_hotkey
};
